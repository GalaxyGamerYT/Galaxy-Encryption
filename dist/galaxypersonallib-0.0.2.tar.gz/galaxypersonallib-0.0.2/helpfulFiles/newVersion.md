# New Version List
1. Increase *version* in *pyproject.toml*.
2. Run *buildModule.py* and follow instructions when prompted.

Run *testDistrubute* to upload to testPyPi.  
Run *mainDistribute* to upload to PyPi.

**Done**
