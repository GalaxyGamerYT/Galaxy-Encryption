import os

os.system('cmd /k "py -m twine upload --skip-existing --repository testpypi dist/*"')
