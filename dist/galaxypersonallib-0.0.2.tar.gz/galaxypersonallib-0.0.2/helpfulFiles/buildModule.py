import os

os.system('cmd /k "cd ../ & py -m build"')
